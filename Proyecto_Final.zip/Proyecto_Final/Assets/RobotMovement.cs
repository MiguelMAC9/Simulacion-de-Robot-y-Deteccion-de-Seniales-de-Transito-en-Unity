using UnityEngine;

public class RobotMovement : MonoBehaviour
{
    public float speed = 5f; // Velocidad ajustable del robot

    void Update()
    {
        // Mueve el robot hacia adelante a una velocidad constante
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
    }
}
