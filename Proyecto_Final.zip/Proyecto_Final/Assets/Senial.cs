using UnityEngine;

public class Senial : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Signal"))
        {
            Debug.Log("Señal detectada!");
        }
    }
}
